package com.niit.SkillMappingBackEnd.Entity;

import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class Skill {

	private int empId;
	private int id;
	private String skillname;
	private String certification;
	private String experince;


	public String getExperince() {
		return experince;
	}

	public void setExperince(String experince) {
		this.experince = experince;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public int getId() {
		return id;
	}

	public void setId(int Id) {
		this.id = id;
	}

	public String getSkillname() {
		return skillname;
	}

	public void setSkillname(String skillname) {
		this.skillname = skillname;
	}

	public String getCertification() {
		return certification;
	}

	public void setCertification(String certification) {
		this.certification = certification;
	}

	
	

}

