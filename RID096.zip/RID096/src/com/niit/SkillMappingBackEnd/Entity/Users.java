package com.niit.SkillMappingBackEnd.Entity;


	import java.util.regex.Matcher;
	import java.util.regex.Pattern;

	public class Users {

		private int empid;
		private String name;
		private String dateofbirth;
		private String emailid;
		private String gender;
		private String contact_no;
		private String qualification;
		private String department;
		private String authentication;
		private String supervisior;
		
		private String password;	
		
		public int getEmpId() {
			return empid;
		}
		public void setEmpId(int empId) {
			this.empid = empId;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getDob() {
			return dateofbirth;
		}
		public void setDob(String dob) {
			this.dateofbirth = dob;
		}
		public String getEmailId() {
			return emailid;
		}
		public void setEmailId(String emailId) {
			emailid = emailId;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getContactnumber() {
			return contact_no;
		}
		public void setContactnumber(String contactnumber) {
			this.contact_no = contactnumber;
		}
		public String getQualification() {
			return qualification;
		}
		public void setQualification(String qualification) {
			this.qualification = qualification;
		}
		
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			department = department;
		}
		public String getSupervicer() {
			return supervisior;
		}
		public void setSupervicer(String supervicer) {
			this.supervisior = supervicer;
		}

		public String getAuthentification() {
			return authentication;
		}
		public void setAuthentification(String authentification) {
			authentication = authentification;
		}
		
	}



